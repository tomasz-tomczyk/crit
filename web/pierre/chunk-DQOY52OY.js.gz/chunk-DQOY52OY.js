import{a}from"./chunk-ALTLFZIS.js";import"./chunk-OOJM4CTU.js";export{a as default};
