var o=()=>{throw new Error("@pierre/highlights is not bundled in Crit; use preferredHighlighter 'shiki-js'")},e=class{constructor(){o()}},t=o,s=()=>!1,n={};export{e as a,t as b,s as c,n as d};
