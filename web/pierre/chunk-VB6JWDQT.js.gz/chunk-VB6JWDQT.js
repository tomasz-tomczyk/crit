import{a,b,c,d}from"./chunk-72HOVMUB.js";import"./chunk-OOJM4CTU.js";export{d as createOnigurumaEngine,c as getDefaultWasmLoader,a as loadWasm,b as setDefaultWasmLoader};
